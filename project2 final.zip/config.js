// API key
const API_KEY = "pk.eyJ1IjoiY2xhZHltb24iLCJhIjoiY2s4Z2ptZTdjMDJibzNsbWZtNWdtaXdvNCJ9.EcF1Ri-Sf1aWxGaREhKibQ";
